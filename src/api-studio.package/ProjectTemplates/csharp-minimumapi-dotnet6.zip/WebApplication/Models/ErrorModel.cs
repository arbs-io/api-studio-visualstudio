#nullable enable
namespace $safeprojectname$
{
    internal class ErrorModel
    {
        public int statusCode { get; set; } = 200;

        public string? Message { get; set; } = "";
    }
}
